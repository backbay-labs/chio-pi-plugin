#!/usr/bin/env python3
"""Isolated local-archive lifecycle observations; no kernel acceptance claim."""
import concurrent.futures, hashlib, json, os, subprocess, tarfile, time
from pathlib import Path
BASE=Path('/tmp/chio-final-codex-pi-artifact-lifecycle-20260910')
BASE.mkdir(mode=0o700)
SPECS={
 'codex':{'name':'@chio/codex-plugin','archive':'/Users/connor/.local/share/chio-required-candidates/20260909/packages/chio-codex-plugin-0.3.0.tgz','sha256':'ac4f14ee4073abdc0c9ff2b4771e99adf7a871d084a9b488513f5d28eae56874','previous':'/tmp/chio-codex-retained-artifacts/chio-codex-plugin-0.3.0-740225b7b0be.tgz','previousSha256':'740225b7b0bef72634ee6e04b159565f0c75b494a69ce496b6a9b73dcbe50e30','bin':'chio-codex','main':'dist/cli/main.js'},
 'pi':{'name':'@chio/pi-plugin','archive':'/Users/connor/.local/share/chio-required-candidates/20260909/packages/chio-pi-plugin-0.1.0.tgz','sha256':'ec6095390b9eae233540b73aee0ad2fef6977c36122dd30aa2779329b1897aa1','previous':'/tmp/chio-pi-subscription-70557f4-20260909/chio-pi-plugin-0.1.0.tgz','previousSha256':'78257af62fc840d8806dd9d90f124ff8c0a2a9b63f3588a4adb6bee4a44a6960','bin':'chio-pi','main':'dist/protected-cli.js'}}
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n');path.chmod(0o600)
def verify(archive,package):
 count=0
 with tarfile.open(archive) as stream:
  for member in stream:
   if not member.isfile():continue
   assert member.name.startswith('package/')
   rel=Path(member.name[8:]);assert not rel.is_absolute() and '..' not in rel.parts
   assert (package/rel).read_bytes()==stream.extractfile(member).read(),str(rel)
   count+=1
 return count

def run(host):
 spec=SPECS[host];out=BASE/host;out.mkdir(mode=0o700);prefix=out/'consumer';prefix.mkdir(mode=0o700)
 evidence=out/'evidence';evidence.mkdir(mode=0o700)
 (evidence/'driver.py').write_bytes(Path(__file__).read_bytes())
 assert sha(spec['archive'])==spec['sha256'] and sha(spec['previous'])==spec['previousSha256']
 records=[]
 def execute(label,args):
  env=os.environ.copy();env.pop('NODE_OPTIONS',None)
  start=time.monotonic();result=subprocess.run(args,cwd=prefix,capture_output=True,text=True,env=env,timeout=180)
  (evidence/(label+'.stdout')).write_text(result.stdout);(evidence/(label+'.stderr')).write_text(result.stderr)
  records.append({'case':label,'command':args,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start});save(evidence/'runs.json',records)
  if result.returncode:raise RuntimeError(label+' failed; original evidence retained')
 package=prefix/'node_modules'/spec['name']
 npm=['npm','--userconfig','/dev/null','--registry','https://registry.npmjs.org']
 common=['--prefix',str(prefix),'--ignore-scripts','--no-audit','--no-fund']
 if host=='pi':
  execute('public-peer-install',npm+['install',*common,'--cache',str(out/'peer-empty-cache'),'--install-strategy=nested','@earendil-works/pi-coding-agent@0.85.1'])
  save(evidence/'public-peer-identity.json',{'package':json.loads((prefix/'node_modules/@earendil-works/pi-coding-agent/package.json').read_text()),'lock':json.loads((prefix/'package-lock.json').read_text()),'claim':'Public pinned peer installation; no kernel/host execution'})
 def install(label,archive):
  extra=['--install-strategy=nested'] if host=='pi' else []
  execute(label,npm+['install',*common,'--offline','--cache',str(out/(label+'-empty-cache')),*extra,archive])
  records[-1]['archiveSha256']=sha(archive);records[-1]['filesVerified']=verify(archive,package);save(evidence/'runs.json',records)
 install('install-previous',spec['previous']);previous_launcher=sha(package/spec['main'])
 # Preserve an independent predecessor consumer for the later real-kernel session upgrade.
 previous_prefix=out/'previous-consumer'
 import shutil
 shutil.copytree(prefix,previous_prefix,symlinks=True)
 verify(spec['previous'],previous_prefix/'node_modules'/spec['name'])
 install('upgrade-current',spec['archive']);assert sha(package/spec['main'])!=previous_launcher
 execute('current-help',['node',str(package/spec['main']),'--help'])
 execute('remove-current',npm+['uninstall',*common,'--offline','--cache',str(out/'removal-empty-cache'),spec['name']])
 assert not package.exists() and not (prefix/'node_modules/.bin'/spec['bin']).exists()
 install('reinstall-current',spec['archive'])
 execute('reinstalled-help',['node',str(package/spec['main']),'--help'])
 identity={**spec,'packageDirectory':str(package),'previousPackageDirectory':str(previous_prefix/'node_modules'/spec['name']),
  'sourceDriverSha256':sha(__file__),'node':subprocess.check_output(['node','--version'],text=True).strip(),'npm':subprocess.check_output(['npm','--version'],text=True).strip(),
  'kernelUsed':False,'normalProfileModified':False,'passed':True,'skips':0,'claim':'Local frozen archive upgrade/removal/reinstallation only; real-host final kernel tests and public delivery remain open'}
 save(evidence/'identity.json',identity);print(json.dumps({'host':host,'passed':True,'filesVerified':verify(spec['archive'],package)}),flush=True)
 return identity
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 result=list(pool.map(run,SPECS))
save(BASE/'installations.json',result)
