#!/usr/bin/env python3
"""Run existing bounded native Codex/Pi cases against one explicitly frozen kernel.

The root coordinator owns each host's useful workflow and common 33-command
matrix. This records the remaining native delivery, lifecycle, confinement,
expiry, budget and storage cases independently for these two hosts. Supplemental
provider fixtures remain labeled; no result is a publication or acceptance claim.
"""
import argparse, concurrent.futures, hashlib, json, os, socket, signal, sqlite3, subprocess, shutil, tarfile, time, uuid
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
p=argparse.ArgumentParser(description=__doc__)
for key in ['kernel','output','owner-root']:p.add_argument('--'+key,type=Path,required=True)
p.add_argument('--kernel-sha256',required=True);p.add_argument('--kernel-source',required=True)
p.add_argument('--hosts',nargs='+',choices=['codex','pi'],default=['codex','pi'])
p.add_argument('--stage',choices=['native','storage','all'],default='all')
a=p.parse_args()
ROOT=Path('/Users/connor/Medica/backbay/standalone/arc/.worktrees/required-agent-integrations-20260909')
REPOS={'codex':Path('/Users/connor/Medica/backbay/standalone/chio-codex-plugin/.worktrees/required-agent-integrations-20260909'),'pi':Path('/Users/connor/Medica/backbay/standalone/chio-pi-plugin/.worktrees/final-native-qualification-20260910')}
INSTALLATIONS=Path('/tmp/chio-final-codex-pi-artifact-lifecycle-r3-20260910/installations.json')
AUTH=Path('/Users/connor/.local/share/chio-required-operators/native-subscription-auth-20260909/codex/profile/auth.json')
OPERATOR_BRIDGE=Path('/Users/connor/.local/share/chio-required-candidates/20260909/install/operator-bridge/node_modules/@chio/bridge')
IMAGE='sha256:188cb84d5d0bb4063d4ce5a3b9c3832445a5acda5604911cda80a9136d1850a0'
OWNER=ROOT/'integrations/required-agents/serve-filesystem.py'
PREPARE=ROOT/'integrations/required-agents/prepare-session.py'
SHARED=ROOT/'scripts/acceptance/host-approvals.py'
POLICY=ROOT/'integrations/required-agents/filesystem-policy.yaml'
INSTALL={entry['name'].split('/')[1].removesuffix('-plugin'):entry for entry in json.loads(INSTALLATIONS.read_text())}

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n');path.chmod(0o600)
def verify_package(spec,previous=False):
 archive=spec['previous'] if previous else spec['archive']
 expected=spec['previousSha256'] if previous else spec['sha256']
 assert sha(archive)==expected
 package=Path(spec['previousPackageDirectory'] if previous else spec['packageDirectory']);count=0
 with tarfile.open(archive) as stream:
  for member in stream:
   if not member.isfile():continue
   assert member.name.startswith('package/')
   rel=Path(member.name[8:]);assert not rel.is_absolute() and '..' not in rel.parts
   assert (package/rel).read_bytes()==stream.extractfile(member).read(),str(rel)
   count+=1
 return count
assert sha(a.kernel)==a.kernel_sha256 and len(a.kernel_source)==40
assert len(set(a.hosts))==len(a.hosts)
assert a.owner_root.is_absolute() and a.output.is_absolute()
a.output.mkdir(mode=0o700,exist_ok=False);a.owner_root.mkdir(mode=0o700,parents=True,exist_ok=True)
assert not a.owner_root.stat().st_mode & 0o077
(a.output/'driver.py').write_bytes(Path(__file__).read_bytes())
(a.output/'installations.json').write_bytes(INSTALLATIONS.read_bytes())
save(a.output/'identity.json',{'kernelSha256':a.kernel_sha256,'kernelSource':a.kernel_source,'binary':str(a.kernel),'kernelVersion':subprocess.check_output([str(a.kernel),'--version'],text=True).strip(),'resourceImage':IMAGE,'hosts':a.hosts,'stage':a.stage,'claim':'Bounded final-candidate native observations; source release checks and publication remain separate'})

def host(name):
 spec=INSTALL[name];package=Path(spec['packageDirectory']);repo=REPOS[name];out=a.output/name;out.mkdir(mode=0o700)
 bridge=package/'node_modules/@chio/bridge';records=[];base=59241 if name=='codex' else 59251
 installation=package.parents[1]
 def installed_files():
  return {str(path.relative_to(installation)):sha(path) for path in sorted(installation.rglob('*')) if path.is_file() and not path.is_symlink()}
 def installed_links():
  result={str(path.relative_to(installation)):os.readlink(path) for path in sorted(installation.rglob('*')) if path.is_symlink()}
  assert all((installation/path).resolve().is_relative_to(installation.resolve()) for path in result)
  return result
 installed_at_start=installed_files();links_at_start=installed_links()
 save(out/'installed-files-at-start.json',installed_at_start);save(out/'installed-links-at-start.json',links_at_start)
 native_codex=Path('/Users/connor/.bun/install/global/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex')
 assert sha(native_codex)=='b973d440acac501fd2594a43e7ca9ce41e0a65b9dfb28d0d7a7837c99e1261e3'
 node=Path(shutil.which('node')).resolve();native_identities={str(native_codex):sha(native_codex),str(node):sha(node)}
 save(out/'native-identities.json',{'executables':native_identities,'nativeCodexVersion':subprocess.check_output([str(native_codex),'--version'],text=True).strip(),'nodeVersion':subprocess.check_output([str(node),'--version'],text=True).strip(),'installedRegularFiles':len(installed_at_start)})
 driver_hashes={str(f):sha(f) for f in [OWNER,PREPARE,SHARED,ROOT/'integrations/required-agents/qualification/storage_fault.py',ROOT/'integrations/required-agents/qualification/stdio_response_barrier.py',*sorted((ROOT/'scripts/acceptance').glob('*.mjs')),REPOS['codex']/'scripts/subscription-faults.mjs',*sorted((repo/'scripts').glob('*.py')),*sorted((repo/'scripts').glob('*.mjs'))]}
 save(out/'source-identity.json',{'repository':str(repo),'commit':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'dirty':subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).splitlines(),'driverHashesAtStart':driver_hashes,'archiveSha256':spec['sha256'],'archiveFilesVerified':verify_package(spec),'previousArchiveFilesVerified':verify_package(spec,previous=True)})
 def run(label,command,timeout=1800,env=None):
  started=time.monotonic();timed_out=False;code=None
  with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:
   child=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=env,start_new_session=True)
   try:code=child.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    timed_out=True
    rows=[tuple(map(int,line.split())) for line in subprocess.check_output(['ps','-axo','pid=,ppid=,pgid='],text=True).splitlines() if line.strip()]
    descendants={child.pid}
    while True:
     found=descendants|{pid for pid,parent,group in rows if parent in descendants}
     if found==descendants:break
     descendants=found
    groups={group for pid,parent,group in rows if pid in descendants and group==pid}|{child.pid}
    save(out/(label+'.timeout-processes.json'),{'createdDriverPid':child.pid,'descendantPidsAtTimeout':sorted(descendants),'createdProcessGroups':sorted(groups),'originalPrivateStateRetained':True})
    for group in groups:
     try:os.killpg(group,signal.SIGTERM)
     except ProcessLookupError:pass
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:pass
    for group in groups:
     try:os.killpg(group,signal.SIGKILL)
     except ProcessLookupError:pass
    code=child.wait(timeout=10)
  row={'case':label,'command':command,'exitCode':code,'timedOut':timed_out,'elapsedSeconds':time.monotonic()-started}
  records.append(row);save(out/'runs.json',records);print(json.dumps({'host':name,**{k:row[k] for k in ['case','exitCode','timedOut']}}),flush=True)
  if code!=0:raise RuntimeError(label+' failed; original private state and evidence retained')
 def owner(label,offset,policy=POLICY):
  state=a.owner_root/(name+'-'+label);volume='chio-required-final-'+name+'-'+label+'-20260910'
  with socket.socket() as sock:sock.bind(('127.0.0.1',base+offset))
  run(label+'-owner-start',['python3',str(OWNER),'start','--state-dir',str(state),'--kernel',str(a.kernel),'--kernel-sha256',a.kernel_sha256,'--image',IMAGE,'--volume',volume,'--port',str(base+offset),'--policy',str(policy)])
  deadline=time.monotonic()+40
  while not (state/'sessions.sqlite.admission.kernel.pub').exists():
   if time.monotonic()>deadline:raise TimeoutError('owner signer unavailable')
   time.sleep(.1)
  return state
 def prepare(state,label):
  run(label+'-prepare',['python3',str(PREPARE),'--operator-state',str(state),'--bridge',str(bridge)])
  config=Path((out/(label+'-prepare.stdout')).read_text().strip());assert config.is_relative_to(state.resolve())
  return config
 def shared(state,label,suite,*extra):
  run(label,['python3',str(SHARED),'--host',name,'--operator-state',str(state),'--package-dir',str(package),'--model-auth-file',str(AUTH),'--suite',suite,'--output',str(out/label),*extra])
 def expiry(state):
  started=time.time();config=prepare(state,'actual-capability');prepared=time.time();conf=json.loads(config.read_text())
  with sqlite3.connect('file:'+str(state/'sessions.sqlite')+'?mode=ro',uri=True) as conn:
   row=conn.execute('SELECT record_json FROM remote_active_sessions WHERE session_id=?',(conf['execution']['sessionId'],)).fetchone()
  caps=json.loads(row[0])['issued_capabilities'];assert len(caps)==1;cap=caps[0]
  assert cap['id']==conf['execution']['capabilityId'] and cap['subject']==conf['execution']['subjectKey']
  body={k:v for k,v in cap.items() if k not in ['signature','algorithm']}
  Ed25519PublicKey.from_public_bytes(bytes.fromhex(cap['issuer'])).verify(bytes.fromhex(cap['signature']),json.dumps(body,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
  assert cap['expires_at']-cap['issued_at']==10 and conf['sessionCredential']['expiresAt']==cap['expires_at'] and prepared<cap['expires_at']
  op=json.loads((state/'operator.json').read_text());binding=out/'actual-capability-binding.json'
  save(binding,{'kernelSource':a.kernel_source,'kernelSha256':a.kernel_sha256,'image':IMAGE,'policySha256':op['policySha256'],'capability':cap,'sessionCredential':conf['sessionCredential'],'gatewayConfig':str(config),'capabilitySignatureVerifiedAgainstEmbeddedIssuer':True,'issuerTrustSource':'Exact capability read from the operator-controlled owner SQLite record; capability issuer is distinct from the receipt signer','signatureBody':'schema-aware','credentialRequestedTtlSeconds':900,'preparationStartedAtEpoch':started,'preparedAtEpoch':prepared,'claim':'Actual owner-issued ten-second capability read independently from SQLite; no rows or clocks modified'})
  shared(state,'actual-capability-expiry','expired-capability','--existing-config',str(config),'--capability-expiry-binding',str(binding))
 try:
  if a.stage in ['native','all']:
   state=owner('native',0);prepare(state,'normal-resource')
   op=json.loads((state/'operator.json').read_text())
   run('seed-approved',['docker','run','--rm','--network','none','--read-only','--user','1000:1000','--cap-drop','ALL','--mount','type=volume,src='+op['volume']+',dst=/workspace','--entrypoint','node',IMAGE,'-e',"require('fs').writeFileSync('/workspace/approved.txt','independent approved fixture\\n')"])
   common=['--operator-state',str(state),'--package-dir',str(package)]
   if name=='codex':
    run('native-patch',['python3',str(repo/'scripts/qualify-http-host.py'),*common,'--model-auth-file',str(AUTH),'--output',str(out/'native-patch'),'--cases','native','tool-error'])
    run('lifecycle',['python3',str(repo/'scripts/qualify-subscription-lifecycle.py'),*common,'--archive',spec['archive'],'--model-auth-file',str(AUTH),'--output',str(out/'lifecycle'),'--cases','plugin-omitted','gateway-missing','host-missing','init-malformed','init-timeout','init-crash','sigterm-after-effect','sigkill-after-effect','parallel-request','cancel-before-dispatch','kernel-network-refused','journal-before-dispatch','journal-after-effect'],timeout=3600)
    for case,fault in [('host-response-loss','drop-host-response.mjs'),('result-substitution','substitute-host-result.mjs'),('gateway-crash','crash-host-gateway.mjs')]:
     run(case,['python3',str(repo/'scripts/qualify-http-host.py'),*common,'--model-auth-file',str(AUTH),'--output',str(out/case),'--cases',case,'--fault-injector',str(ROOT/'scripts/acceptance'/fault)])
    run('installation-native',['python3',str(repo/'scripts/qualify-subscription-install.py'),'--operator-state',str(state),'--archive',spec['archive'],'--previous-archive',spec['previous'],'--reference-package',str(package),'--model-auth-file',str(AUTH),'--output',str(out/'installation-native')])
    run('paired-tool-interval',['python3',str(repo/'scripts/qualify-subscription-timing.py'),'--owner-launcher',str(OWNER),'--state-dir',str(a.owner_root/'codex-timing'),'--kernel',str(a.kernel),'--kernel-sha256',a.kernel_sha256,'--policy',str(POLICY),'--package-dir',str(package),'--archive',spec['archive'],'--model-auth-file',str(AUTH),'--image',IMAGE,'--volume','chio-required-final-codex-timing-20260910','--port','59247','--output',str(out/'paired-tool-interval')])
    launch=out/'installation-native/reinstalled-workflow/useful/launch.json'
    run('native-confinement',['python3',str(repo/'scripts/probe-subscription-boundary.py'),'--launch',str(launch),'--archive',spec['archive'],'--package',str(package),'--output',str(out/'native-confinement')])
   else:
    run('native-extra',['python3',str(repo/'scripts/qualify-http-host.py'),*common,'--provider','openai-codex','--model','gpt-5.5','--codex-auth',str(AUTH),'--output',str(out/'native-extra'),'--cases','tool-error','disabled-route'])
    run('lifecycle',['python3',str(repo/'scripts/qualify-lifecycle.py'),*common,'--archive',spec['archive'],'--previous-package-dir',spec['previousPackageDirectory'],'--previous-archive',spec['previous'],'--codex-auth',str(AUTH),'--output',str(out/'lifecycle')])
    run('cutpoints',['python3',str(repo/'scripts/qualify-storage-cutpoints.py'),*common,'--codex-auth',str(AUTH),'--fault-injector',str(REPOS['codex']/'scripts/subscription-faults.mjs'),'--output',str(out/'cutpoints')])
    for case,fault in [('host-response-loss','drop-host-response.mjs'),('result-substitution','substitute-host-result.mjs'),('gateway-crash','crash-host-gateway.mjs')]:
     run(case,['python3',str(repo/'scripts/qualify-http-host.py'),*common,'--provider','openai-codex','--model','gpt-5.5','--codex-auth',str(AUTH),'--output',str(out/case),'--cases',case,'--result-fault-injector' if case=='result-substitution' else '--fault-injector',str(ROOT/'scripts/acceptance'/fault)])
    run('paired-tool-interval',['python3',str(repo/'scripts/measure-tool-interval.py'),*common,'--codex-auth',str(AUTH),'--resource','/workspace/approved.txt','--output',str(out/'paired-tool-interval')])
   config=prepare(state,'parallel-fixture')
   script='probe-subscription-parallel.mjs' if name=='codex' else 'probe-parallel.mjs'
   run('forced-parallel',['node',str(repo/'scripts'/script),*common,'--gateway-config',str(config),'--archive',spec['archive'],'--model-auth-file' if name=='codex' else '--codex-auth',str(AUTH),'--output',str(out/'forced-parallel')])
   if name=='pi':
    trace=out/'native-extra/tool-error/host.stdout.jsonl';events=[json.loads(line) for line in trace.read_text().splitlines() if line.startswith('{')]
    source=json.loads((out/'native-extra/results.json').read_text())[0];config=Path(source['privateState'])/'gateway.json'
    # Harmless canaries are outside the guest-owned profile, in the same protected owner directory.
    for label in ['owner','other-host']:(state/(label+'-confinement-canary.json')).write_text('{"canary":"designated confinement marker"}\n')
    env=os.environ.copy();env['CHIO_PI_EVIDENCE_DIR']=str(out/'native-confinement')
    run('native-confinement',['node',str(repo/'scripts/probe-sandbox.mjs'),str(trace),str(state/'owner-confinement-canary.json'),str(state/'other-host-confinement-canary.json'),str(config)],env=env)
    launch=next(event for event in events if event['type']=='chio_protected_runtime')
    canary=Path(launch['installation'])/'chio-probe-readonly-control.txt'
    assert canary.read_text()=='immutable installation probe';canary.unlink()
   budget_policy=out/'budget-policy.yaml';text=POLICY.read_text();assert text.count('max_invocations: 64')==1
   budget_policy.write_text(text.replace('max_invocations: 64','max_invocations: 3'));budget_state=owner('budget',1,budget_policy)
   shared(budget_state,'aggregate-budget','aggregate-budget')
   expiry_policy=out/'expiry-policy.yaml';assert text.count('ttl: 3600')==2
   expiry_policy.write_text(text.replace('ttl: 3600','ttl: 10'));expiry_state=owner('expiry',2,expiry_policy);expiry(expiry_state)
  if a.stage in ['storage','all']:
   command=['python3',str(repo/'scripts/qualify-kernel-storage.py'),'--helper',str(ROOT/'integrations/required-agents/qualification/storage_fault.py'),'--owner-launcher',str(OWNER),'--kernel',str(a.kernel),'--kernel-sha256',a.kernel_sha256,'--image',IMAGE,'--policy',str(POLICY),'--operator-bridge',str(OPERATOR_BRIDGE),'--package-dir',str(package),'--owner-root',str(a.owner_root/(name+'-storage')),'--output',str(out/'kernel-storage'),'--name-prefix','final-'+name+'-20260910','--ports',str(base+3),str(base+4),str(base+5),'--cases','after-receipt','before-admission','after-admission']
   command+=['--archive',spec['archive'],'--model-auth-file',str(AUTH)] if name=='codex' else ['--codex-auth',str(AUTH)]
   run('kernel-storage',command,timeout=3600)
  assert verify_package(spec)>0 and sha(a.kernel)==a.kernel_sha256
  assert installed_files()==installed_at_start and installed_links()==links_at_start
  assert all(sha(path)==expected for path,expected in native_identities.items())
  changed=[path for path,expected in driver_hashes.items() if sha(path)!=expected];assert not changed,changed
  save(out/'summary.json',{'passed':True,'commandCount':len(records),'skips':0,'kernelSha256':a.kernel_sha256,'archiveSha256':spec['sha256'],'runtimeAndDriverIdentitiesUnchanged':True,'claim':'Bounded observations only; common matrix and public delivery remain separate'})
  return {'host':name,'passed':True,'commandCount':len(records)}
 except Exception as error:
  save(out/'failure.json',{'type':type(error).__name__,'message':str(error),'originalStateRetained':True})
  return {'host':name,'passed':False,'commandCount':len(records)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:result=list(pool.map(host,a.hosts))
save(a.output/'results.json',result)
raise SystemExit(0 if all(row['passed'] for row in result) else 1)
